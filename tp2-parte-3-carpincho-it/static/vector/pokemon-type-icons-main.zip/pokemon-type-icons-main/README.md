# Pokémon Type Icons
 A set of SVG icons of Pokémon types.  
 This is a recreation of the type icons found in Brilliant Diamond, Shining Pearl, Legends: Arceus, Scarlet, and Violet. I wasn't able to find a good vector version of this set, so I made one. They're not perfect - if you find a problem, [create an issue](https://github.com/partywhale/pokemon-type-icons/issues). Or better yet, fix it and put in a pull request!  

Free to use under MIT license.